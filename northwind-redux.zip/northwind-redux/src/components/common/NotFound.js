import React, { Component } from 'react'

export default class NotFound extends Component {
    render() {
        return (
            <div>
                <h2>Sayfa bulunamadı</h2>
            </div>
        )
    }
}
